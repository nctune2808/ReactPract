# 📱 Playground for ReactiveSearch Native components
#### Building a Nested Drawer in React Native

#### [Featured on freeCodeCamp](https://medium.freecodecamp.org/how-to-build-a-nested-drawer-menu-with-react-native-a1c2fdcab6c9) :tada:

![ezgif-1-d1ea1bab66](https://user-images.githubusercontent.com/5961873/38978733-dc548a64-43d5-11e8-827e-2fe0b64cac9c.gif)

## Demo

Try the app in your phone using [expo app](https://expo.io/@dhruvdutt/native-kitchensink).

![](https://i.imgur.com/EkjqFcj.png)

## Further learning

Read [how we built it](https://medium.freecodecamp.org/how-to-build-a-nested-drawer-menu-with-react-native-a1c2fdcab6c9).
