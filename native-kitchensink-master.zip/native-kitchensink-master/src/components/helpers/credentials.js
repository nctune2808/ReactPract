export const GOOD_BOOKS = {
	app: 'good-books-ds',
	credentials: 'nY6NNTZZ6:27b76b9f-18ea-456c-bc5e-3a5263ebc63d',
	type: 'good-books-ds',
};

export const GITXPLORE = {
	app: 'gitxplore-app',
	credentials: '4oaS4Srzi:f6966181-1eb4-443c-8e0e-b7f38e7bc316',
	type: 'gitxplore-latest',
};
